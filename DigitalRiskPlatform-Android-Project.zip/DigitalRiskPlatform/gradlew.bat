@rem Gradle wrapper script for Windows
@rem Run gradlew.bat build
gradle build