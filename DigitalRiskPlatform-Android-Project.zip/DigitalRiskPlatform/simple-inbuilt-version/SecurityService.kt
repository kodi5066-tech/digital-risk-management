// 24/7 Always-On Background Service with BootReceiver
// See app/src/main/java/com/drp/security/SecurityService.kt in documentation