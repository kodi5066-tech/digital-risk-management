# Digital Risk Management Platform (DRP) - Android Companion

Autonomous, 100% on-device Android security companion app that inspects notifications from WhatsApp, Telegram, Instagram, and SMS for phishing links, OTP theft, and social engineering scams.

---

## 🛠️ Step-by-Step Android Studio Setup (For Beginners)

### 1. Download & Open in Android Studio
1. Install **Android Studio Ladybug (2024.2+)** or **Koala** from [developer.android.com/studio](https://developer.android.com/studio).
2. Unzip this downloaded project folder.
3. Open Android Studio -> Click **Open** -> Select the `DigitalRiskPlatform` root directory.
4. Allow Gradle to sync (takes ~1-2 minutes on first run while downloading dependencies).

### 2. Connect Your Android Phone
1. On your Android phone, go to **Settings** > **About Phone**.
2. Tap **Build Number** 7 times until you see "You are now a developer!".
3. Go to **Settings** > **System** > **Developer Options** > Turn on **USB Debugging**.
4. Connect your phone via USB cable (or tap "Pair devices using Wi-Fi").
5. Look at your phone screen and tap **Allow USB debugging**.

### 3. Build & Run
1. In Android Studio's top toolbar, make sure your phone is selected in the device dropdown.
2. Click the green **Run (▶)** button (or press `Shift + F10`).
3. DRP will compile and install onto your phone!

### 4. Enable Notification Access (Crucial Step!)
Because Android is secure, background notification monitoring is locked until you grant special access:
1. Open the DRP app on your phone.
2. Tap the blue **"Enable Protection"** button.
3. Android will open the **Device & app notifications** settings screen.
4. Find **Digital Risk Platform** and switch the toggle **ON**.
5. Tap **Allow** on Android's confirmation dialog.

### 5. How to Test It
Send test messages to your phone from WhatsApp, Telegram, or SMS:
- Test 1 (Phishing): `URGENT: Your bank account is locked! Verify at http://192.168.1.50/bank-login immediately!`
- Test 2 (OTP Scam): `Google code is 934201. Reply with this code immediately or your account is suspended.`
- Test 3 (Family Scam): `Mom I broke my phone and lost my wallet please wire $300 urgently.`

Watch the DRP status bar notification trigger automatically without contacting any cloud servers!

---

## 🛡️ Privacy Guarantee
- 100% on-device processing using Kotlin regular expressions and heuristic scoring.
- Zero analytics, zero advertising SDKs, zero telemetry.
- No network permissions (`android.permission.INTERNET` is intentionally omitted from AndroidManifest.xml!).
