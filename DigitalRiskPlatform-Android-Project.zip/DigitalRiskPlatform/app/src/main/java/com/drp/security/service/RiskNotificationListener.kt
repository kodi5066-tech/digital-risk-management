package com.drp.security.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import com.drp.security.MainActivity
import com.drp.security.R
import com.drp.security.data.ThreatRecord
import com.drp.security.data.ThreatRepository
import com.drp.security.detector.RiskDetector
import com.drp.security.detector.RiskLevel

/**
 * Background service authorized by Android to inspect incoming notifications.
 *
 * PRIVACY GUARANTEE:
 * - Operates entirely offline on the physical device.
 * - Extracts only notification text & title.
 * - Never transmits data to external servers or cloud endpoints.
 */
class RiskNotificationListener : NotificationListenerService() {

    private val TAG = "DRP_SecurityListener"
    private val ALERT_CHANNEL_ID = "drp_security_alerts_channel"
    private val NOTIFICATION_ID_BASE = 1000

    // Monitored high-volume messaging application packages
    private val TARGET_PACKAGES = setOf(
        "com.whatsapp",                                 // WhatsApp
        "com.whatsapp.w4b",                             // WhatsApp Business
        "org.telegram.messenger",                      // Telegram
        "org.telegram.messenger.web",
        "com.instagram.android",                        // Instagram Direct
        "com.google.android.apps.messaging",            // Google Messages (SMS/RCS)
        "com.android.mms",                              // Standard SMS
        "com.samsung.android.messaging"                 // Samsung SMS
    )

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        ThreatRepository.init(applicationContext)
        Log.i(TAG, "Digital Risk Platform Notification Watchdog Initialized.")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        val packageName = sbn.packageName

        // CRITICAL DEFENSE 1: Never inspect our own package!
        // This prevents an infinite loop where DRP warns about its own security warning.
        if (packageName == applicationContext.packageName) {
            return
        }

        // CRITICAL DEFENSE 2: Check if user has paused protection in privacy settings
        if (!ThreatRepository.isProtectionActive()) {
            return
        }

        // Extract metadata
        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val bigText = extras.getCharSequence("android.bigText")?.toString() ?: text

        val fullMessage = if (bigText.isNotEmpty()) bigText else text

        // Check if content is redacted (e.g. lockscreen privacy mode)
        if (fullMessage.isBlank() && title.isBlank()) {
            Log.d(TAG, "Notification content hidden by Android privacy settings from $packageName")
            return
        }

        // Optional filter: prioritize monitored messaging apps, or monitor all third-party
        val appName = getFriendlyAppName(packageName)

        // Perform 100% LOCAL rule-based heuristic risk detection
        val result = RiskDetector.analyze(title, fullMessage)

        // If risk is MEDIUM or HIGH, log threat and dispatch user warning
        if (result.riskLevel == RiskLevel.HIGH || result.riskLevel == RiskLevel.MEDIUM) {
            val record = ThreatRecord(
                id = System.currentTimeMillis().toString(),
                timestamp = System.currentTimeMillis(),
                sourceApp = packageName,
                appName = appName,
                sender = if (title.isNotBlank()) title else "Unknown Sender",
                previewText = fullMessage,
                riskLevel = result.riskLevel,
                category = result.category,
                detectedTriggers = result.triggers,
                recommendation = result.recommendation,
                isRedacted = result.isRedacted
            )

            // Save threat locally
            ThreatRepository.addThreat(record)

            // Emit native Android security warning notification
            showSecurityAlert(record)

            // If user enabled floating overlay, trigger overlay service
            if (ThreatRepository.isOverlayEnabled()) {
                FloatingOverlayService.showThreatWarning(applicationContext, record)
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Clean up when notification is dismissed if necessary
    }

    private fun showSecurityAlert(record: ThreatRecord) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = when (record.riskLevel) {
            RiskLevel.HIGH -> "⚠️ DRP Alert: High Risk Message in ${record.appName}"
            RiskLevel.MEDIUM -> "🛡️ DRP Notice: Suspicious Content in ${record.appName}"
            else -> "DRP Notification Notice"
        }

        val summary = if (record.detectedTriggers.isNotEmpty()) {
            record.detectedTriggers.first()
        } else {
            "Potential social engineering or phishing detected."
        }

        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield_alert)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "$summary\n\n💡 Recommendation: ${record.recommendation}"
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val alertId = (NOTIFICATION_ID_BASE + (record.timestamp % 1000)).toInt()
        notificationManager.notify(alertId, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Security Threat Warnings"
            val descriptionText = "Displays proactive security alerts when suspicious links, OTP scams, or phishing are detected"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(ALERT_CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun getFriendlyAppName(packageName: String): String {
        return when (packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
            "org.telegram.messenger", "org.telegram.messenger.web" -> "Telegram"
            "com.instagram.android" -> "Instagram"
            "com.google.android.apps.messaging" -> "Google Messages (SMS)"
            "com.android.mms" -> "SMS / MMS"
            "com.samsung.android.messaging" -> "Samsung Messages"
            else -> {
                try {
                    val pm = packageManager
                    val appInfo = pm.getApplicationInfo(packageName, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    packageName.substringAfterLast('.')
                }
            }
        }
    }
}