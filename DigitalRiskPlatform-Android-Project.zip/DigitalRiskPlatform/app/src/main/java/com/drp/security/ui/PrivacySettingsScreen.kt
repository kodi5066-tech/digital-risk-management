package com.drp.security.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drp.security.data.ThreatRepository

@Composable
fun PrivacySettingsScreen(
    onOpenNotificationSettings: () -> Unit
) {
    val context = LocalContext.current
    var isProtectionActive by remember { mutableStateOf(ThreatRepository.isProtectionActive()) }
    var isOverlayEnabled by remember { mutableStateOf(ThreatRepository.isOverlayEnabled()) }
    var showClearDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Privacy & Controls",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )

        // Master Protection Switch
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Background Notification Guard", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "Temporarily halt notification inspection without revoking Android permissions.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isProtectionActive,
                    onCheckedChange = { checked ->
                        isProtectionActive = checked
                        ThreatRepository.setProtectionActive(checked)
                    }
                )
            }
        }

        // Floating Overlay Permission Toggle
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Floating Threat Overlay", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "Displays an on-screen floating chip when a high-risk message is detected (requires 'Display over other apps').",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isOverlayEnabled,
                    onCheckedChange = { checked ->
                        if (checked && !Settings.canDrawOverlays(context)) {
                            // Prompt user for overlay permission
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        } else {
                            isOverlayEnabled = checked
                            ThreatRepository.setOverlayEnabled(checked)
                        }
                    }
                )
            }
        }

        // Android Special Access Settings Shortcut
        OutlinedButton(
            onClick = onOpenNotificationSettings,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Reconfigure Android Notification Access")
        }

        // Clear Local History Button
        Button(
            onClick = { showClearDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Delete, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Clear Local Threat History")
        }

        // Privacy Principles Breakdown
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Core Privacy Principles", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("1. 100% Offline: Zero servers, telemetry, or analytics.", fontSize = 12.sp)
                Text("2. Read-Only: DRP cannot read encrypted chats inside WhatsApp, change messages, or block sender accounts.", fontSize = 12.sp)
                Text("3. Redacted Notifications: When Android lockscreen hides notification content, DRP respects your privacy and does not fabricate text.", fontSize = 12.sp)
                Text("4. Heuristic Disclaimers: Rules may trigger false positives or miss novel zero-day phishing schemes.", fontSize = 12.sp)
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Erase History?") },
            text = { Text("This will permanently delete all stored security incidents from local device storage.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        ThreatRepository.clearHistory()
                        showClearDialog = false
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}