package com.drp.security.detector

enum class RiskLevel {
    SAFE,
    LOW,
    MEDIUM,
    HIGH
}

enum class ThreatCategory {
    PHISHING_LINK,
    OTP_PASSWORD_THEFT,
    URGENT_PAYMENT_SCAM,
    SUSPICIOUS_PHRASE,
    CONTENT_HIDDEN
}

data class DetectionResult(
    val riskLevel: RiskLevel,
    val category: ThreatCategory,
    val triggers: List<String>,
    val recommendation: String,
    val isRedacted: Boolean
)

object RiskDetector {

    private val SUSPICIOUS_TLDS = setOf(
        "xyz", "top", "work", "buzz", "club", "tk", "ml", "ga", "cf", "gq", "rest", "monster", "site", "online"
    )

    private val SHORTENER_DOMAINS = setOf(
        "bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "goo.gl"
    )

    private val AUTH_KEYWORDS = listOf(
        "bank", "login", "verify", "secure", "account", "update", "signin", "wallet", "crypto", "auth", "support"
    )

    private val TRUSTED_DOMAINS = listOf(
        "google.com", "apple.com", "microsoft.com", "amazon.com", "whatsapp.com", "telegram.org"
    )

    /**
     * Inspects title and text of incoming notification completely offline.
     */
    fun analyze(title: String, text: String): DetectionResult {
        val combined = "$title $text".trim()
        val lower = combined.lowercase()

        // 1. Redacted or Hidden Check
        if (text.isBlank() ||
            lower.contains("content hidden") ||
            lower.contains("sensitive notification") ||
            lower.contains("unlock to view")
        ) {
            return DetectionResult(
                riskLevel = RiskLevel.LOW,
                category = ThreatCategory.CONTENT_HIDDEN,
                triggers = listOf("Notification content is hidden or redacted by Android privacy controls"),
                recommendation = "DRP cannot inspect this message because Android lockscreen security has redacted the preview text.",
                isRedacted = true
            )
        }

        val triggers = mutableListOf<String>()
        var score = 0
        var category = ThreatCategory.SUSPICIOUS_PHRASE

        // 2. Phishing URL Analysis
        val urlRegex = Regex("""(https?://[^s]+)""", RegexOption.IGNORE_CASE)
        val matches = urlRegex.findAll(combined).map { it.value }.toList()

        if (matches.isNotEmpty()) {
            for (url in matches) {
                val uLower = url.lowercase()

                // Check raw IP address
                if (Regex("""https?://d{1,3}.d{1,3}.d{1,3}.d{1,3}""").containsMatchIn(url)) {
                    triggers.add("Direct IP address URL detected: $url")
                    score += 50
                }

                // Check suspicious TLDs
                for (tld in SUSPICIOUS_TLDS) {
                    if (uLower.contains(".$tld/") || uLower.endsWith(".$tld")) {
                        triggers.add("High-risk domain extension (.$tld) in link: $url")
                        score += 40
                        break
                    }
                }

                // Check URL shortener
                for (shortener in SHORTENER_DOMAINS) {
                    if (uLower.contains(shortener)) {
                        triggers.add("Shortened URL hiding destination ($shortener)")
                        score += 25
                        break
                    }
                }

                // Check deceptive auth keywords on unverified domains
                val isTrusted = TRUSTED_DOMAINS.any { uLower.contains(it) }
                if (!isTrusted) {
                    for (keyword in AUTH_KEYWORDS) {
                        if (uLower.contains(keyword)) {
                            triggers.add("Deceptive security keyword '$keyword' in link")
                            score += 35
                            break
                        }
                    }
                }

                // Insecure HTTP
                if (uLower.startsWith("http://")) {
                    triggers.add("Unencrypted HTTP web link")
                    score += 15
                }
            }
        }

        // 3. OTP & Credential Theft Detection
        val otpKeywords = listOf("otp", "verification code", "passcode", "security code", "pin code", "2fa code")
        val shareKeywords = listOf("share", "send", "reply", "forward", "give me", "text me", "tell me")

        val hasOtp = otpKeywords.any { lower.contains(it) }
        val hasShare = shareKeywords.any { lower.contains(it) }

        if (hasOtp && hasShare) {
            triggers.add("Solicitation to reply or share an OTP / verification code")
            score += 45
        } else if (hasOtp) {
            triggers.add("Contains verification code mention (Security note: Never share this)")
            score += 15
        }

        // 4. Urgent Payment Scams & Impersonation
        val urgentPhrases = mapOf(
            "wire money" to "Urgent money transfer request",
            "send money" to "Direct money solicitation",
            "gift card" to "Unusual payment demand (gift cards)",
            "lost my phone" to "Family impersonation scam pattern ('lost phone')",
            "broke my phone" to "Family impersonation scam pattern ('broke phone')",
            "hospital bill" to "Emergency distress / hospital money demand",
            "customs fee" to "Package clearance delivery scam",
            "package held" to "Package delivery fee extortion",
            "bitcoin" to "Cryptocurrency transfer request",
            "arrest warrant" to "Legal threat / authority scare tactic",
            "irs notice" to "Government agency scare tactic"
        )

        for ((key, reason) in urgentPhrases) {
            if (lower.contains(key)) {
                triggers.add(reason)
                score += 35
            }
        }

        // 5. General Suspicious Threat Phrases
        val suspicionPhrases = mapOf(
            "account suspended" to "False account suspension threat",
            "account will be terminated" to "Account termination coercion",
            "act within 24 hours" to "Artificial urgency deadline",
            "lottery winner" to "Fake lottery / prize winner claim",
            "congratulations you won" to "Unsolicited reward scam",
            "click immediately" to "Pressured action demand"
        )

        for ((key, reason) in suspicionPhrases) {
            if (lower.contains(key)) {
                triggers.add(reason)
                score += 25
            }
        }

        // Determine Category
        if (matches.isNotEmpty() && score >= 35) {
            category = ThreatCategory.PHISHING_LINK
        } else if (hasOtp) {
            category = ThreatCategory.OTP_PASSWORD_THEFT
        } else if (urgentPhrases.keys.any { lower.contains(it) }) {
            category = ThreatCategory.URGENT_PAYMENT_SCAM
        } else if (triggers.isNotEmpty()) {
            category = ThreatCategory.SUSPICIOUS_PHRASE
        }

        // Determine Level and Actionable Advice
        val (riskLevel, recommendation) = when {
            score >= 50 -> Pair(
                RiskLevel.HIGH,
                "CRITICAL: High probability of phishing or credential theft. Do NOT open links, transfer funds, or reply with security codes."
            )
            score >= 25 -> Pair(
                RiskLevel.MEDIUM,
                "CAUTION: Suspicious urgency or unverified links detected. Contact the sender through an official trusted phone number."
            )
            score > 0 -> Pair(
                RiskLevel.LOW,
                "LOW: Informational notification. Exercise general caution before interacting."
            )
            else -> Pair(
                RiskLevel.SAFE,
                "No suspicious risk indicators identified."
            )
        }

        return DetectionResult(
            riskLevel = riskLevel,
            category = category,
            triggers = if (triggers.isNotEmpty()) triggers else listOf("Standard message pattern"),
            recommendation = recommendation,
            isRedacted = false
        )
    }
}