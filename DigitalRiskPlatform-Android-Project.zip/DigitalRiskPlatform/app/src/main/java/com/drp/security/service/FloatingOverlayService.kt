package com.drp.security.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.drp.security.R
import com.drp.security.data.ThreatRecord

/**
 * Optional floating overlay displayed on top of other applications
 * when a critical threat is intercepted.
 */
class FloatingOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val appName = intent?.getStringExtra("EXTRA_APP_NAME") ?: "App"
        val trigger = intent?.getStringExtra("EXTRA_TRIGGER") ?: "Suspicious Link"

        if (Settings.canDrawOverlays(this)) {
            showOverlay(appName, trigger)
        }

        return START_NOT_STICKY
    }

    private fun showOverlay(appName: String, trigger: String) {
        if (overlayView != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_threat_warning, null)

        val titleView = overlayView?.findViewById<TextView>(R.id.overlay_title)
        val subtitleView = overlayView?.findViewById<TextView>(R.id.overlay_subtitle)
        val closeBtn = overlayView?.findViewById<View>(R.id.overlay_close)

        titleView?.text = "DRP Shield: Threat in $appName"
        subtitleView?.text = trigger

        closeBtn?.setOnClickListener {
            removeOverlay()
            stopSelf()
        }

        // Auto dismiss after 8 seconds
        overlayView?.postDelayed({
            removeOverlay()
            stopSelf()
        }, 8000)

        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeOverlay() {
        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
    }

    companion object {
        fun showThreatWarning(context: Context, record: ThreatRecord) {
            if (Settings.canDrawOverlays(context)) {
                val intent = Intent(context, FloatingOverlayService::class.java).apply {
                    putExtra("EXTRA_APP_NAME", record.appName)
                    putExtra("EXTRA_TRIGGER", record.detectedTriggers.firstOrNull() ?: "High Risk Content")
                }
                context.startService(intent)
            }
        }
    }
}