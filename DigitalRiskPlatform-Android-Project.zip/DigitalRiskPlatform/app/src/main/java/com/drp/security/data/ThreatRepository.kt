package com.drp.security.data

import android.content.Context
import android.content.SharedPreferences
import com.drp.security.detector.RiskLevel
import com.drp.security.detector.ThreatCategory
import org.json.JSONArray
import org.json.JSONObject

data class ThreatRecord(
    val id: String,
    val timestamp: Long,
    val sourceApp: String,
    val appName: String,
    val sender: String,
    val previewText: String,
    val riskLevel: RiskLevel,
    val category: ThreatCategory,
    val detectedTriggers: List<String>,
    val recommendation: String,
    val isRedacted: Boolean
)

object ThreatRepository {

    private const val PREFS_NAME = "drp_security_storage"
    private const val KEY_THREATS_JSON = "key_stored_threats"
    private const val KEY_PROTECTION_ENABLED = "key_protection_active"
    private const val KEY_OVERLAY_ENABLED = "key_overlay_active"

    private lateinit var prefs: SharedPreferences
    private val memoryCache = mutableListOf<ThreatRecord>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadFromDisk()
    }

    @Synchronized
    fun addThreat(record: ThreatRecord) {
        memoryCache.add(0, record)
        if (memoryCache.size > 200) {
            memoryCache.removeAt(memoryCache.size - 1)
        }
        saveToDisk()
    }

    @Synchronized
    fun getAllThreats(): List<ThreatRecord> {
        return memoryCache.toList()
    }

    @Synchronized
    fun clearHistory() {
        memoryCache.clear()
        prefs.edit().remove(KEY_THREATS_JSON).apply()
    }

    fun isProtectionActive(): Boolean {
        return prefs.getBoolean(KEY_PROTECTION_ENABLED, true)
    }

    fun setProtectionActive(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROTECTION_ENABLED, enabled).apply()
    }

    fun isOverlayEnabled(): Boolean {
        return prefs.getBoolean(KEY_OVERLAY_ENABLED, false)
    }

    fun setOverlayEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_OVERLAY_ENABLED, enabled).apply()
    }

    private fun saveToDisk() {
        val array = JSONArray()
        for (item in memoryCache) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("sourceApp", item.sourceApp)
                put("appName", item.appName)
                put("sender", item.sender)
                put("previewText", item.previewText)
                put("riskLevel", item.riskLevel.name)
                put("category", item.category.name)
                put("recommendation", item.recommendation)
                put("isRedacted", item.isRedacted)

                val triggersArray = JSONArray()
                item.detectedTriggers.forEach { triggersArray.put(it) }
                put("detectedTriggers", triggersArray)
            }
            array.put(obj)
        }
        prefs.edit().putString(KEY_THREATS_JSON, array.toString()).apply()
    }

    private fun loadFromDisk() {
        memoryCache.clear()
        val jsonString = prefs.getString(KEY_THREATS_JSON, null) ?: return
        try {
            val array = JSONArray(jsonString)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val triggers = mutableListOf<String>()
                val triggersArr = obj.optJSONArray("detectedTriggers")
                if (triggersArr != null) {
                    for (j in 0 until triggersArr.length()) {
                        triggers.add(triggersArr.getString(j))
                    }
                }

                memoryCache.add(
                    ThreatRecord(
                        id = obj.getString("id"),
                        timestamp = obj.getLong("timestamp"),
                        sourceApp = obj.getString("sourceApp"),
                        appName = obj.getString("appName"),
                        sender = obj.getString("sender"),
                        previewText = obj.getString("previewText"),
                        riskLevel = RiskLevel.valueOf(obj.getString("riskLevel")),
                        category = ThreatCategory.valueOf(obj.getString("category")),
                        detectedTriggers = triggers,
                        recommendation = obj.getString("recommendation"),
                        isRedacted = obj.optBoolean("isRedacted", false)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}