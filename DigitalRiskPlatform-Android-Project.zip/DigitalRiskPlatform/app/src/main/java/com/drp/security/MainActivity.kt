package com.drp.security

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.drp.security.data.ThreatRepository
import com.drp.security.service.RiskNotificationListener
import com.drp.security.ui.HomeScreen
import com.drp.security.ui.DashboardScreen
import com.drp.security.ui.PrivacySettingsScreen
import com.drp.security.ui.theme.DigitalRiskTheme

class MainActivity : ComponentActivity() {

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            // Notification permission granted for Android 13+
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThreatRepository.init(applicationContext)

        // Request POST_NOTIFICATIONS on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            DigitalRiskTheme {
                MainAppScaffold(
                    isNotificationAccessGranted = { isNotificationServiceEnabled(this) },
                    onOpenNotificationSettings = { openNotificationListenerSettings(this) }
                )
            }
        }
    }

    companion object {
        /**
         * Verifies if DRP's NotificationListenerService has been granted permission by the user
         */
        fun isNotificationServiceEnabled(context: Context): Boolean {
            val pkgName = context.packageName
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            )
            return flat != null && flat.contains(pkgName)
        }

        /**
         * Directly launches Android Settings to the Notification Access permission toggle
         */
        fun openNotificationListenerSettings(context: Context) {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).apply {
                    putExtra(
                        Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                        ComponentName(context, RiskNotificationListener::class.java).flattenToString()
                    )
                }
            } else {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}

enum class ScreenTab {
    HOME,
    DASHBOARD,
    SETTINGS
}

@Composable
fun MainAppScaffold(
    isNotificationAccessGranted: () -> Boolean,
    onOpenNotificationSettings: () -> Unit
) {
    var currentTab by remember { mutableStateOf(ScreenTab.HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == ScreenTab.HOME,
                    onClick = { currentTab = ScreenTab.HOME },
                    label = { Text("Protection") },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Shield, contentDescription = "Home") }
                )
                NavigationBarItem(
                    selected = currentTab == ScreenTab.DASHBOARD,
                    onClick = { currentTab = ScreenTab.DASHBOARD },
                    label = { Text("Threats") },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Warning, contentDescription = "Dashboard") }
                )
                NavigationBarItem(
                    selected = currentTab == ScreenTab.SETTINGS,
                    onClick = { currentTab = ScreenTab.SETTINGS },
                    label = { Text("Privacy") },
                    icon = { Icon(androidx.compose.material.icons.Icons.Default.Lock, contentDescription = "Privacy") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
                ScreenTab.HOME -> HomeScreen(
                    isPermissionGranted = isNotificationAccessGranted(),
                    onEnableProtectionClicked = onOpenNotificationSettings,
                    onNavigateToDashboard = { currentTab = ScreenTab.DASHBOARD }
                )
                ScreenTab.DASHBOARD -> DashboardScreen()
                ScreenTab.SETTINGS -> PrivacySettingsScreen(
                    onOpenNotificationSettings = onOpenNotificationSettings
                )
            }
        }
    }
}